package com.aivideocreator;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private EditText edtText;
    private Spinner spinnerCharacter;
    private Spinner spinnerStyle;
    private Button btnGenerate;
    private Button btnResult;
    private ProgressBar progress;
    private TextView txtStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtText = findViewById(R.id.edtText);
        spinnerCharacter = findViewById(R.id.spinnerCharacter);
        spinnerStyle = findViewById(R.id.spinnerStyle);
        btnGenerate = findViewById(R.id.btnGenerate);
        btnResult = findViewById(R.id.btnResult);
        progress = findViewById(R.id.progress);
        txtStatus = findViewById(R.id.txtStatus);

        setupSpinner(spinnerCharacter, new String[]{"IA elige", "Hombre", "Mujer"});
        setupSpinner(spinnerStyle, new String[]{"Realista", "Comercial", "Cinematográfico"});

        btnGenerate.setOnClickListener(v -> generateDemo());

        btnResult.setOnClickListener(v ->
                Toast.makeText(this,
                        "La conexión con el motor de video IA se agregará en la siguiente etapa.",
                        Toast.LENGTH_LONG).show());
    }

    private void setupSpinner(Spinner spinner, String[] values) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                values
        );
        spinner.setAdapter(adapter);
    }

    private void generateDemo() {
        String text = edtText.getText().toString().trim();

        if (text.isEmpty()) {
            edtText.setError("Escribí primero el texto del video");
            edtText.requestFocus();
            return;
        }

        btnGenerate.setEnabled(false);
        btnResult.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        txtStatus.setVisibility(View.VISIBLE);
        txtStatus.setText("Preparando tu video...");

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            txtStatus.setText("Texto preparado. Motor IA pendiente de conexión.");
            progress.setVisibility(View.GONE);
            btnGenerate.setEnabled(true);
            btnResult.setVisibility(View.VISIBLE);
        }, 1800);
    }
}

# AI Video Creator V1

Proyecto Android inicial para una aplicación de texto a video con IA.

## Qué incluye esta V1
- Pantalla principal.
- Campo de texto de hasta 2000 caracteres.
- Selección de personaje: IA elige / Hombre / Mujer.
- Selección de estilo: Realista / Comercial / Cinematográfico.
- Flujo de generación de prueba.
- Preparación de la interfaz para conectar un servidor y un motor de video IA.

## Importante
Esta versión NO contiene todavía un proveedor real de generación de video. El botón de generación ejecuta un flujo de prueba para verificar la interfaz.

No colocar claves privadas de proveedores dentro de la APK. Las claves deberán permanecer en el servidor.

## Compilar
1. Abrir la carpeta en Android Studio.
2. Esperar la sincronización de Gradle.
3. Conectar un teléfono Android o iniciar un emulador.
4. Ejecutar `app`.
5. Para crear APK: Build > Build APK(s).

Requisitos recomendados:
- Android Studio reciente.
- JDK 17.
- Android SDK 35.
